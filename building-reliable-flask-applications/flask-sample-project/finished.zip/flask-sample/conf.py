aws_access_key_id= 'AKIASFWLXJT2SQJKRD5W'
aws_secret_access_key='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'
region='us-east-2'

lambda_function_name = 'post_logs'